/*
	DBPool - JDBC Connection Pool Manager
	Copyright (c) Giles Winstanley
*/
package snaq.db;

import snaq.util.Reusable;
import java.sql.*;
import java.text.NumberFormat;
import java.util.*;

/**
 * Connection wrapper that implements statement caching.
 * Caching is not performed for statements where additional
 * parameters are supplied (ResultSet type/concurrency).
 * @see snaq.db.CachedStatement
 * @see snaq.db.CachedPreparedStatement
 * @see snaq.db.CachedCallableStatement
 * @author Giles Winstanley
 */
public final class CacheConnection implements Connection, StatementListener, Reusable
{
	protected ConnectionPool pool;
	protected Connection con;
	protected ArrayList ss, ssUsed; // Statement cache
	protected HashMap ps, psUsed;   // PreparedStatement cache
	protected HashMap cs, csUsed;   // CallableStatement cache
	private boolean cacheS, cacheP, cacheC;
	private int ssReq, ssHit;
	private int psReq, psHit;
	private int csReq, csHit;
	private boolean open = true;


	/**
	 * Creates a new CacheConnection object, using the supplied Connection.
	 */
	public CacheConnection(ConnectionPool pool, Connection con)
	{
		this.pool = pool;
		this.con = con;
		setCacheAll(true);
		ssReq = ssHit = psReq = psHit = csReq = csHit = 0;
	}

	/**
	 * Added to provide caching support.
	 */
	void setOpen()
	{
		open = true;
	}

	/**
	 * Added to provide caching support.
	 */
	boolean isOpen()
	{
		return open;
	}

	/**
	 * Sets whether to use caching for Statements.
	 */
	public void setCacheStatements(boolean cache)
	{
		this.cacheS = cache;
		if (ss == null)
		{
			ss = new ArrayList();
			ssUsed = new ArrayList();
		}
	}

	/**
	 * Sets whether to use caching for PreparedStatements.
	 */
	public void setCachePreparedStatements(boolean cache)
	{
		this.cacheP = cache;
		if (ps == null)
		{
			ps = new HashMap();
			psUsed = new HashMap();
		}
	}

	/**
	 * Sets whether to use caching for CallableStatements.
	 */
	public void setCacheCallableStatements(boolean cache)
	{
		this.cacheC = cache;
		if (cs == null)
		{
			cs = new HashMap();
			csUsed = new HashMap();
		}
	}

	/**
	 * Sets whether to use caching for all types of Statement.
	 */
	public void setCacheAll(boolean cache)
	{
		setCacheStatements(cache);
		setCachePreparedStatements(cache);
		setCacheCallableStatements(cache);
	}

	/**
	 * Returns the raw underlying Connection object for which this provides
	 * a wrapper. This is provided as a convenience method for using database-specific
	 * features for which the Connection object needs to be upcast.
	 * (e.g. to use Oracle-specific features needs to be cast to oracle.jdbc.OracleConnection).
	 * <em>To maintain the stability of the pooling system it is important that the
	 * raw connection is not destabilized when used in this way.</em>
	 */
	public Connection getRawConnection()
	{
		return con;
	}


	//******************************
	// Connection interface methods
	//******************************

	public Statement createStatement() throws SQLException
	{
		if (!cacheS)
			return con.createStatement();
		CachedStatement cs = null;
		synchronized(ss)
		{
			ssReq++;
			if (!ss.isEmpty())
			{
				cs = (CachedStatement)ss.remove(0);
				cs.setOpen();
				ssHit++;
				if (pool.isDebug())
					pool.log("Statement cache hit - " + calcHitRate(ssHit, ssReq));
			}
			else
			{
				cs = new CachedStatement(con.createStatement());
				cs.setStatementListener(this);
				cs.setOpen();
				if (pool.isDebug())
					pool.log("Statement cache miss - " + calcHitRate(ssHit, ssReq));
			}
		}
		ssUsed.add(cs);
		return cs;
	}

	/**
	 * Overrides method to provide caching support.
	 */
	public PreparedStatement prepareStatement(String sql) throws SQLException
	{
		if (!cacheP)
			return con.prepareStatement(sql);
		else
		{
			synchronized(ps)
			{
				Object o = ps.get(sql);
				psReq++;
				if (o != null)
				{
					ps.remove(sql);
					CachedPreparedStatement cps = (CachedPreparedStatement)o;
					cps.setOpen();
					psUsed.put(sql, cps);
					psHit++;
					if (pool.isDebug())
						pool.log("PreparedStatement cache hit [" + sql + "] - " + calcHitRate(psHit, psReq));
					return cps;
				}
				else
				{
					CachedPreparedStatement cps = new CachedPreparedStatement(sql, con.prepareStatement(sql));
					cps.setStatementListener(this);
					cps.setOpen();
					ps.put(sql, cps);
					if (pool.isDebug())
						pool.log("PreparedStatement cache miss [" + sql + "] - " + calcHitRate(psHit, psReq));
					return cps;
				}
			}
		}
	}

	/**
	 * Overrides method to provide caching support.
	 */
	public CallableStatement prepareCall(String sql) throws SQLException
	{
		if (!cacheC)
			return con.prepareCall(sql);
		else
		{
			synchronized(cs)
			{
				Object o = cs.get(sql);
				csReq++;
				if (o != null)
				{
					cs.remove(sql);
					CachedCallableStatement ccs = (CachedCallableStatement)o;
					ccs.setOpen();
					csUsed.put(sql, ccs);
					csHit++;
					if (pool.isDebug())
						pool.log("CallableStatement cache hit [" + sql + "] - " + calcHitRate(csHit, csReq));
					return ccs;
				}
				else
				{
					CallableStatement st = con.prepareCall(sql);
					CachedCallableStatement ccs = new CachedCallableStatement(sql, st);
					ccs.setStatementListener(this);
					ccs.setOpen();
					cs.put(sql, ccs);
					if (pool.isDebug())
						pool.log("CallableStatement cache miss [" + sql + "] - " + calcHitRate(csHit, csReq));
					return ccs;
				}
			}
		}
	}
	
	/**
	 * Callback invoked when a statement is closed.
	 */
	public void statementClosed(CachedStatement s) throws SQLException
	{
		if (s instanceof PreparedStatement)
		{
			synchronized(ps)
			{
				String key = ((CachedPreparedStatement)s).getQueryString();
				psUsed.remove(key);
				// If caching disabled close statement
				if (!cacheP)
					s.release();
				else  // else try to recycle it
				{
					try
					{
						s.recycle();
						ps.put(key, s);
					}
					catch (SQLException sqle)
					{
						s.release();
					}
				}
			}
		}
		else if (s instanceof CallableStatement)
		{
			synchronized(cs)
			{
				String key = ((CachedCallableStatement)s).getQueryString();
				csUsed.remove(key);
				// If caching disabled close statement
				if (!cacheC)
					s.release();
				else  // else try to recycle it
				{
					try
					{
						s.recycle();
						cs.put(key, s);
					}
					catch (SQLException sqle)
					{
						s.release();
					}
				}
			}
		}
		else
		{
			synchronized(ss)
			{
				ssUsed.remove(s);
				// If caching disabled close statement
				if (!cacheS)
					s.release();
				else  // else try to recycle it
				{
					try
					{
						s.recycle();
						ss.add(s);
					}
					catch (SQLException sqle)
					{
						s.release();
					}
				}
			}
		}
	}
	
	private String calcHitRate(int hits, int reqs)
	{
		return (reqs == 0) ? "" : (((float)hits / reqs) * 100f) + "% hit rate";
	}

	public String nativeSQL(String sql) throws SQLException
	{
		return con.nativeSQL(sql);
	}

	public void setAutoCommit(boolean autoCommit) throws SQLException
	{
		con.setAutoCommit(autoCommit);
	}

	public boolean getAutoCommit() throws SQLException
	{
		return con.getAutoCommit();
	}

	public void commit() throws SQLException
	{
		con.commit();
	}

	public void rollback() throws SQLException
	{
		con.rollback();
	}
	
	/**
	 * Puts connection back in a state where it can be reused.
	 */
	public void recycle() throws SQLException
	{
		// Close all open Statements
		if (cacheS)
		{
			int count = (ss != null) ? ssUsed.size() : 0;
			if (count > 0)
			{
				if (pool.isDebug())
					pool.log("Cleaning " + count + " cached Statement" + (count > 1 ? "s" : ""));
				synchronized(ss)
				{
					Iterator iter = ss.iterator();
					while (iter.hasNext())
						((Statement)iter.next()).close();
				}
			}
		}
		else
			flushStatements();
		
		// Close all open PreparedStatements
		if (cacheP)
		{
			int count = (ps != null) ? psUsed.size() : 0;
			if (count > 0)
			{
				if (pool.isDebug())
					pool.log("Cleaning " + count + " cached PreparedStatement" + (count > 1 ? "s" : ""));
				synchronized(ps)
				{
					Iterator iter = ps.values().iterator();
					while (iter.hasNext())
						((CachedPreparedStatement)iter.next()).close();
				}
			}
		}
		else
			flushPreparedStatements();

		// Close all open CallableStatements
		if (cacheC)
		{
			int count = (cs != null) ? csUsed.size() : 0;
			if (count > 0)
			{
				if (pool.isDebug())
					pool.log("Cleaning " + count + " cached CallableStatement" + (count > 1 ? "s" : ""));
				synchronized(cs)
				{
					Iterator iter = cs.values().iterator();
					while (iter.hasNext())
						((CachedCallableStatement)iter.next()).close();
				}
			}
		}
		else
			flushCallableStatements();

		// Put connection back in default state
		if (!getAutoCommit())
		{
			try { rollback(); }
			catch (SQLException sqle) { sqle.printStackTrace(); }
			setAutoCommit(true);
		}
		clearWarnings();
	}

	/**
	 * Overrides method to provide caching support.
	 */
	public void close() throws SQLException
	{
		if (!open)
			throw new SQLException("Connection already closed");
		open = false;
		// Hand itself back to the pool
		pool.freeConnection(this);
	}

	/**
	 * Flushes the Statement caches for this connection.
	 */
	protected void flushStatements() throws SQLException
	{
		// Close all cached Statements
		int count = (ss != null) ? ss.size() : 0;
		if (count > 0)
		{
			if (pool.isDebug())
				pool.log("Closing " + count + " cached Statement" + (count > 1 ? "s" : ""));
			Iterator iter = ss.iterator();
			while (iter.hasNext())
				((CachedStatement)iter.next()).release();
			ss.clear();
		}
	}

	/**
	 * Flushes the PreparedStatement cache for this connection.
	 */
	protected void flushPreparedStatements() throws SQLException
	{
		// Close all cached PreparedStatements
		int count = (ps != null) ? ps.size() : 0;
		if (count > 0)
		{
			if (pool.isDebug())
				pool.log("Closing " + count + " cached PreparedStatement" + (count > 1 ? "s" : ""));
			Iterator iter = ps.values().iterator();
			while (iter.hasNext())
				((CachedPreparedStatement)iter.next()).release();
			ps.clear();
		}
	}

	/**
	 * Flushes the CallableStatement cache for this connection.
	 */
	protected void flushCallableStatements() throws SQLException
	{
		// Close all cached CallableStatements
		int count = (cs != null) ? cs.size() : 0;
		if (count > 0)
		{
			if (pool.isDebug())
				pool.log("Closing " + count + " cached CallableStatement" + (count > 1 ? "s" : ""));
			Iterator iter = cs.values().iterator();
			while (iter.hasNext())
				((CachedCallableStatement)iter.next()).release();
			cs.clear();
		}
	}

	/**
	 * Destroys the wrapped connection.
	 */
	public void release() throws SQLException
	{
		open = false;
		ArrayList list = new ArrayList();
		
		try { flushStatements(); }
		catch (SQLException e) { list.add(e); }
		try { flushPreparedStatements(); }
		catch (SQLException e) { list.add(e); }
		try { flushCallableStatements(); }
		catch (SQLException e) { list.add(e); }
		
		try { con.close(); }
		catch (SQLException e) { list.add(e); }
		
		if (!list.isEmpty())
		{
			SQLException sqle = new SQLException("Problem releasing connection resources");
			sqle.setNextException((SQLException)list.get(0));
			throw sqle;
		}
	}

	public boolean isClosed() throws SQLException
	{
		return con.isClosed();
	}

	public DatabaseMetaData getMetaData() throws SQLException
	{
		return con.getMetaData();
	}

	public void setReadOnly(boolean readOnly) throws SQLException
	{
		con.setReadOnly(readOnly);
	}

	public boolean isReadOnly() throws SQLException
	{
		return con.isReadOnly();
	}

	public void setCatalog(String catalog) throws SQLException
	{
		con.setCatalog(catalog);
	}

	public String getCatalog() throws SQLException
	{
		return con.getCatalog();
	}

	public void setTransactionIsolation(int level) throws SQLException
	{
		con.setTransactionIsolation(level);
	}

	public int getTransactionIsolation() throws SQLException
	{
		return con.getTransactionIsolation();
	}

	public SQLWarning getWarnings() throws SQLException
	{
		return con.getWarnings();
	}

	public void clearWarnings() throws SQLException
	{
		con.clearWarnings();
	}

	public Statement createStatement(int resultSetType, int resultSetConcurrency) throws SQLException
	{
		return con.createStatement(resultSetType, resultSetConcurrency);
	}

	public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException
	{
		return con.prepareStatement(sql, resultSetType, resultSetConcurrency);
	}

	public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency) throws SQLException
	{
		return con.prepareCall(sql, resultSetType, resultSetConcurrency);
	}

	public Map getTypeMap() throws SQLException
	{
		return con.getTypeMap();
	}

	public void setTypeMap(Map map) throws SQLException
	{
		con.setTypeMap(map);
	}

	//**********************************
	// Interface methods from JDBC 3.0
	//**********************************

	public void setHoldability(int holdability) throws SQLException
	{
		con.setHoldability(holdability);
	}

	public int getHoldability() throws SQLException
	{
		return con.getHoldability();
	}

	public Savepoint setSavepoint() throws SQLException
	{
		return con.setSavepoint();
	}

	public Savepoint setSavepoint(String name) throws SQLException
	{
		return con.setSavepoint(name);
	}

	public void rollback(Savepoint savepoint) throws SQLException
	{
		con.rollback(savepoint);
	}

	public void releaseSavepoint(Savepoint savepoint) throws SQLException
	{
		con.releaseSavepoint(savepoint);
	}

	public Statement createStatement(int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException
	{
		return con.createStatement(resultSetType, resultSetConcurrency, resultSetHoldability);
	}

	public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException
	{
		return con.prepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
	}

	public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException
	{
		return con.prepareCall(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
	}

	public PreparedStatement prepareStatement(String sql, int autoGeneratedKeys) throws SQLException
	{
		return con.prepareStatement(sql, autoGeneratedKeys);
	}

	public PreparedStatement prepareStatement(String sql, int[] columnIndexes) throws SQLException
	{
		return con.prepareStatement(sql, columnIndexes);
	}

	public PreparedStatement prepareStatement(String sql, String[] columnNames) throws SQLException
	{
		return con.prepareStatement(sql, columnNames);
	}
}